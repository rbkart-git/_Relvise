This training layout is a test of basic knowledge in the field of html and css.
